# Weather-Journal App Project

## Overview
This project is created by Emad Ibrahim as an asynchronous web app that uses Web open weeather API and user data to dynamically update the UI to give you some. This app is created for educational purposes as part of the front-end web developement nanodegree.

## Instructions
After extracting the file on your computer using your command prompt you should run the app by applying the command 'node server.js' while on the same directory that contains the file `server.js`. At this point go to your browser and enter `localhost:8080` it will automatically run the `index.html` and by modifying the zip code  and adding your feeling the resoponce will appear in the text area assinged for it giving you the temperature and you lateset respons.

## Copyrights
All the copyrights reserved to the creator and Udacity.
